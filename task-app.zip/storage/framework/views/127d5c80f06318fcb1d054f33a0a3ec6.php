<?php $__env->startSection('main-content'); ?>
    <div class="card mt-5">
        <div class="card-header">
            <h4>
                Task Edit Form
            </h4>
        </div>

        <div class="card-body">
            <form id="addEmployeeForm" action="<?php echo e(route('task.update', $task->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <ul class="alert alert-warning <?php if($errors->any()): ?> d-block <?php else: ?> d-none <?php endif; ?>" id="error">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="form-group mb-3">
                        <label for="">Title</label>
                        <input type="text" value="<?php echo e($task->title); ?>" name="title" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Description</label>
                        <textarea name="description" class="form-control"><?php echo e($task->description); ?></textarea>
                    </div>

                    <div class="form-group mb-3">
                        <label for="">Tags: </label>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input"
                                       <?php echo e($task->tags->contains($tag->id) ? 'checked' : ''); ?>

                                       name="tags[]" type="checkbox"
                                       value="<?php echo e($tag->id); ?>">
                                <label class="form-check-label" for="inlineCheckbox1"><?php echo e($tag->name); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Task</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task-app\resources\views/task/edit.blade.php ENDPATH**/ ?>