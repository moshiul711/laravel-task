<!--Add Task Modal -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Add Task</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addEmployeeForm" action="<?php echo e(route('task.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <ul class="alert alert-warning <?php if($errors->any()): ?> d-block <?php else: ?> d-none <?php endif; ?>" id="error">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="form-group mb-3">
                        <label for="">Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Description</label>
                        <textarea name="description" class="form-control" required></textarea>
                    </div>

                    <div class="form-group mb-3">
                        <label for="">Tags: </label>
                        <?php if(count($tags) > 0): ?>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="tags[]" required type="checkbox"
                                        value="<?php echo e($tag->id); ?>">
                                    <label class="form-check-label" for="inlineCheckbox1"><?php echo e($tag->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a data-bs-toggle="modal" data-bs-target="#addTagModal"
                                class="btn btn-primary btn-sm float-end">Add Tag
                            </a>
                        <?php else: ?>
                            <a data-bs-toggle="modal" data-bs-target="#addTagModal"
                                class="btn btn-primary btn-sm float-end">Add Tag
                            </a>
                        <?php endif; ?>

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Task</button>
                </div>
            </form>
        </div>
    </div>
</div>






<div class="modal fade" id="addTagModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Add Tag</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('tag.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <ul class="alert alert-warning d-none" id="error"></ul>
                    <div class="form-group mb-3">
                        <label for="">Tag Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Tag</button>
                </div>
            </form>
        </div>
    </div>
</div>



<div class="modal fade" id="filtering" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Task Filtering</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('task.filter')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <ul class="alert alert-warning d-none" id="error"></ul>
                    <div class="form-group mb-3">
                        <label for="">Tag Name</label>
                        <select class="form-control" name="tag_id">
                            <option selected>---Select Tag---</option>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Serach</button>
                </div>
            </form>
        </div>
    </div>
</div>




<script src="<?php echo e(asset('/')); ?>task/js/bundle.min.js"></script>
<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>

<?php if(session('success')): ?>
    <script>
        Command: toastr["success"]("<?php echo e(session('success')); ?>")
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "3000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\task-app\resources\views/task/task_js.blade.php ENDPATH**/ ?>