<?php $__env->startSection('main-content'); ?>
    <div class="card mt-5">
        <div class="card-header">
            <h4>Task Management
                <a data-bs-toggle="modal" data-bs-target="#addTaskModal" class="btn btn-primary btn-sm float-end mx-2">Add Task</a>
                <a data-bs-toggle="modal" data-bs-target="#filtering" class="btn btn-primary btn-sm float-end me-5">Filte</a>
            </h4>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>SL.</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Tag(s)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($task->title); ?></td>
                                <td><?php echo e($task->description); ?></td>
                                <td>
                                    <?php if(count($task->tags) > 1): ?>
                                        <?php $__currentLoopData = $task->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag->name . ' ,'); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $task->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag->name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    
                                    <a href="<?php echo e(route('task.edit', $task->id)); ?>" class="btn btn-sm btn-primary"><i
                                            class="fa-regular fa-pen-to-square"></i></a>
                                    <a href="<?php echo e(route('task.delete', $task->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are You Sure To Delete')" ><i
                                            class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task-app\resources\views/task/index.blade.php ENDPATH**/ ?>